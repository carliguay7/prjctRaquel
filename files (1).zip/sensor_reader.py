#!/usr/bin/env python3
"""
Sensor de Temperatura DS18B20 - Raspberry Pi
Llegeix dades del sensor submergible, desa a CSV/JSON i puja a GitHub
"""

import os
import csv
import json
import random
import time
import subprocess
from datetime import datetime
from pathlib import Path

# ─── CONFIGURACIÓ ───────────────────────────────────────────────────────────
SENSOR_ID = "28-00000xxxxxxx"          # ID del sensor DS18B20 (canviar pel real)
BASE_DIR = Path("/sys/bus/w1/devices") # Ruta del sistema 1-Wire a Raspberry Pi
CSV_FILE = Path("dades/temperatures.csv")
JSON_FILE = Path("dades/temperatures.json")
GITHUB_REPO = "https://github.com/USUARI/sensor-temperatura.git"  # Canviar
MAX_REGISTRES = 10000                   # Màxim de registres al JSON

# ─── SIMULACIÓ (quan no hi ha sensor físic connectat) ───────────────────────
SIMULAR_SENSOR = True   # Posar False quan el sensor estigui connectat

def simular_temperatura() -> float:
    """Genera una temperatura simulada realista (com un estany o piscina)."""
    hora = datetime.now().hour
    # Simula cicle diari: més fresc de nit, més càlid a la tarda
    base = 18.0 + 6.0 * abs(hora - 14) / 14 * -1 + 6.0
    soroll = random.gauss(0, 0.3)
    return round(base + soroll, 4)

# ─── LECTURA REAL DEL SENSOR DS18B20 ────────────────────────────────────────
def llegir_sensor_real() -> float | None:
    """Llegeix la temperatura del sensor DS18B20 via 1-Wire."""
    sensor_path = BASE_DIR / SENSOR_ID / "w1_slave"
    try:
        with open(sensor_path, "r") as f:
            lines = f.readlines()
        if lines[0].strip().endswith("YES"):
            temp_str = lines[1].split("t=")[1]
            return round(int(temp_str) / 1000.0, 4)
        else:
            print("⚠️  Sensor no llest (CRC error)")
            return None
    except FileNotFoundError:
        print(f"❌ Sensor no trobat a {sensor_path}")
        return None
    except Exception as e:
        print(f"❌ Error llegint sensor: {e}")
        return None

def llegir_temperatura() -> float | None:
    """Selecciona entre sensor real o simulació."""
    if SIMULAR_SENSOR:
        return simular_temperatura()
    return llegir_sensor_real()

# ─── GESTIÓ DE FITXERS ───────────────────────────────────────────────────────
def inicialitzar_fitxers():
    """Crea els directoris i fitxers si no existeixen."""
    CSV_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not CSV_FILE.exists():
        with open(CSV_FILE, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "temperatura_c", "data", "hora", "sensor_id"])
        print(f"✅ Creat fitxer CSV: {CSV_FILE}")
    if not JSON_FILE.exists():
        JSON_FILE.write_text(json.dumps({"registres": [], "total": 0}, indent=2))
        print(f"✅ Creat fitxer JSON: {JSON_FILE}")

def desar_temperatura(temperatura: float):
    """Desa la mesura al CSV i JSON."""
    ara = datetime.now()
    timestamp = ara.isoformat()
    data_str = ara.strftime("%Y-%m-%d")
    hora_str = ara.strftime("%H:%M:%S")

    # ── Desa al CSV ──
    with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([timestamp, temperatura, data_str, hora_str, SENSOR_ID])

    # ── Desa al JSON ──
    try:
        dades = json.loads(JSON_FILE.read_text())
    except Exception:
        dades = {"registres": [], "total": 0}

    nou_registre = {
        "timestamp": timestamp,
        "temperatura_c": temperatura,
        "data": data_str,
        "hora": hora_str,
        "sensor_id": SENSOR_ID
    }
    dades["registres"].append(nou_registre)
    dades["total"] = len(dades["registres"])
    dades["ultima_lectura"] = timestamp

    # Limita el nombre de registres
    if len(dades["registres"]) > MAX_REGISTRES:
        dades["registres"] = dades["registres"][-MAX_REGISTRES:]

    JSON_FILE.write_text(json.dumps(dades, indent=2, ensure_ascii=False))
    print(f"💾 [{timestamp}] Temperatura: {temperatura:.2f}°C → desada")

# ─── PUJADA A GITHUB ─────────────────────────────────────────────────────────
def pujar_github(missatge: str = None):
    """Fa commit i push dels fitxers de dades a GitHub."""
    if missatge is None:
        missatge = f"📊 Actualització dades {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    try:
        subprocess.run(["git", "add", str(CSV_FILE), str(JSON_FILE)], check=True)
        subprocess.run(["git", "commit", "-m", missatge], check=True)
        subprocess.run(["git", "push"], check=True)
        print(f"🚀 Pujat a GitHub: {missatge}")
    except subprocess.CalledProcessError as e:
        print(f"⚠️  Error pujant a GitHub: {e}")

# ─── BUCLE PRINCIPAL ─────────────────────────────────────────────────────────
def executar(interval_segons: int = 300, pujar_cada: int = 3):
    """
    Executa el bucle de lectura.
    interval_segons: temps entre lectures (default 5 min)
    pujar_cada: puja a GitHub cada N lectures
    """
    inicialitzar_fitxers()
    print(f"\n🌡️  Iniciant monitorització de temperatura")
    print(f"   Mode: {'SIMULACIÓ' if SIMULAR_SENSOR else 'SENSOR REAL'}")
    print(f"   Interval: {interval_segons}s | Puja GitHub cada {pujar_cada} lectures\n")

    comptador = 0
    try:
        while True:
            temperatura = llegir_temperatura()
            if temperatura is not None:
                desar_temperatura(temperatura)
                comptador += 1
                if comptador % pujar_cada == 0:
                    pujar_github()
            time.sleep(interval_segons)
    except KeyboardInterrupt:
        print("\n⛔ Aturat per l'usuari. Pujant dades finals...")
        pujar_github("🛑 Aturada manual - dades finals")

# ─── EINES ADDICIONALS ───────────────────────────────────────────────────────
def generar_dades_historiques(dies: int = 30):
    """Genera dades simulades dels últims N dies (per proves)."""
    inicialitzar_fitxers()
    print(f"⚙️  Generant {dies} dies de dades simulades...")
    ara = datetime.now()
    for d in range(dies * 24 * 12):  # cada 5 minuts
        dt = ara.replace(
            hour=(d // 12) % 24,
            minute=(d % 12) * 5,
            second=0
        )
        # Simula variació realista
        hora = dt.hour
        base = 17.0 + 8.0 * (1 - abs(hora - 14) / 14)
        temp = round(base + random.gauss(0, 0.5), 4)
        timestamp = dt.isoformat()
        with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                timestamp, temp,
                dt.strftime("%Y-%m-%d"),
                dt.strftime("%H:%M:%S"),
                SENSOR_ID
            ])
    print(f"✅ Generades {dies * 24 * 12} lectures al CSV")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--genera-demo":
        generar_dades_historiques(30)
        pujar_github("📦 Dades demo generades")
    else:
        # Lectura cada 5 min, puja cada 3 lectures (= 3 vegades/dia aprox si s'ajusta)
        executar(interval_segons=300, pujar_cada=96)  # 96 x 5min = 8h → 3x/dia
