# 🌡️ Monitor Temperatura DS18B20 — Raspberry Pi

Sistema complet de recollida, emmagatzematge i visualització de temperatures amb sensor submergible DS18B20.

---

## 📁 Estructura del Projecte

```
sensor-temperatura/
├── sensor_reader.py        ← Script principal Python
├── index.html              ← Dashboard web (GitHub Pages)
├── dades/
│   ├── temperatures.csv    ← Historial complet de lectures
│   └── temperatures.json   ← Dades per al web
└── README.md
```

---

## ⚙️ 1. Configuració de la Raspberry Pi

### Activar 1-Wire (per al DS18B20)
```bash
# Editar config.txt
sudo nano /boot/config.txt

# Afegir al final:
dtoverlay=w1-gpio

# Reiniciar
sudo reboot

# Verificar sensor detectat
ls /sys/bus/w1/devices/
# Ha d'apareixer: 28-xxxxxxxxxxxx
```

### Instal·lar dependències Python
```bash
pip install gitpython   # opcional, per push avançat
```

---

## 🐍 2. Configuració del Script Python

Editar `sensor_reader.py`:

```python
SENSOR_ID = "28-00000xxxxxxx"   # Canviar per l'ID real del sensor
GITHUB_REPO = "https://github.com/USUARI/sensor-temperatura.git"
SIMULAR_SENSOR = False  # Posar False amb sensor real connectat
```

### Executar manualment
```bash
python3 sensor_reader.py
```

### Generar dades de demo (per proves)
```bash
python3 sensor_reader.py --genera-demo
```

---

## ⏰ 3. Automatització amb Cron (3 vegades al dia)

```bash
crontab -e
```

Afegir:
```
# Lectura cada 5 minuts
*/5 * * * * /usr/bin/python3 /home/pi/sensor-temperatura/sensor_reader.py --single >> /var/log/sensor.log 2>&1

# Push a GitHub a les 8h, 14h i 20h
0 8 * * * cd /home/pi/sensor-temperatura && git add dades/ && git commit -m "Push matí $(date)" && git push
0 14 * * * cd /home/pi/sensor-temperatura && git add dades/ && git commit -m "Push migdia $(date)" && git push
0 20 * * * cd /home/pi/sensor-temperatura && git add dades/ && git commit -m "Push vespre $(date)" && git push
```

---

## 🌐 4. Configuració GitHub Pages

1. Crear repositori a GitHub: `sensor-temperatura`
2. Clonar a la Raspberry Pi:
   ```bash
   git clone https://github.com/USUARI/sensor-temperatura.git
   cd sensor-temperatura
   ```
3. Activar GitHub Pages:
   - Repositori → Settings → Pages
   - Source: `main` branch, carpeta `/root`
4. La web serà accessible a: `https://USUARI.github.io/sensor-temperatura/`

### Configurar Git a la Raspberry Pi
```bash
git config --global user.email "email@exemple.com"
git config --global user.name "Nom"

# Per evitar introduir contrasenya cada vegada (SSH):
ssh-keygen -t ed25519 -C "email@exemple.com"
cat ~/.ssh/id_ed25519.pub  # Copiar a GitHub → Settings → SSH Keys
```

---

## 📱 5. App Mòbil (API REST simple)

Per recollir i actualitzar dades des del mòbil, crear un endpoint Flask:

```python
# api_servidor.py
from flask import Flask, jsonify, request
import json
from pathlib import Path

app = Flask(__name__)
JSON_FILE = Path("dades/temperatures.json")

@app.route('/api/dades')
def get_dades():
    return jsonify(json.loads(JSON_FILE.read_text()))

@app.route('/api/ultima')
def get_ultima():
    data = json.loads(JSON_FILE.read_text())
    return jsonify(data['registres'][-1] if data['registres'] else {})

@app.route('/api/afegir', methods=['POST'])
def afegir():
    """Permet afegir lectures manuals des de l'app mòbil."""
    nova = request.json
    data = json.loads(JSON_FILE.read_text())
    data['registres'].append(nova)
    data['total'] = len(data['registres'])
    JSON_FILE.write_text(json.dumps(data, indent=2))
    return jsonify({"ok": True})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
```

Executar: `python3 api_servidor.py`  
Accedir des del mòbil: `http://IP_RASPBERRY:5000/api/dades`

---

## 💡 6. Funcionalitats Addicionals

| Funcionalitat | Descripció |
|---|---|
| **Alertes per email** | Si temp > 30°C o < 5°C, envia email amb `smtplib` |
| **Alertes Telegram** | Bot de Telegram que envia notificacions en temps real |
| **Exportar PDF** | Informe mensual automàtic en PDF |
| **Comparativa anual** | Comparar temperatures entre anys |
| **Predicció** | Predicció de temperatura amb mitjanes mòbils |
| **Multi-sensor** | Suport per múltiples sensors DS18B20 a la mateixa línia |

---

## 🔌 Connexió del Sensor DS18B20

```
Raspberry Pi          DS18B20
─────────────         ─────────
Pin 1 (3.3V) ────── Cable Vermell (VDD+)
Pin 6 (GND)  ────── Cable Negre  (GND)
Pin 7 (GPIO4)─┬──── Cable Groc   (DATA)
              │
           4.7kΩ    ← Resistència pull-up obligatòria
              │
           3.3V
```

---

## 📊 Format del JSON

```json
{
  "registres": [
    {
      "timestamp": "2024-03-15T14:30:00",
      "temperatura_c": 21.4375,
      "data": "2024-03-15",
      "hora": "14:30:00",
      "sensor_id": "28-00000abc1234"
    }
  ],
  "total": 1,
  "ultima_lectura": "2024-03-15T14:30:00"
}
```
